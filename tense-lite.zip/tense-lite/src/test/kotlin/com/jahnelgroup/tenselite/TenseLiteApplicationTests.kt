package com.jahnelgroup.tenselite

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TenseLiteApplicationTests {

	@Test
	fun contextLoads() {
	}

}
