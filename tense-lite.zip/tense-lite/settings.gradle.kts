rootProject.name = "tense-lite"
